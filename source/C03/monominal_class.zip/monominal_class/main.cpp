#include <iostream>
#include "monominal.h"

using namespace std;

int main()
{
    monominal T;
    cin>>T;
}